#===============================================================================
# VMware vSphere configuration
#===============================================================================

# vCenter IP or FQDN #
vsphere_vcenter = "pvcn01.sof.intra"

# vSphere username used to deploy the infrastructure #
vsphere_user = "user_svc_ansible"

# Skip the verification of the vCenter SSL certificate (true/false) #
vsphere_unverified_ssl = "true"

# vSphere datacenter name where the infrastructure will be deployed #
vsphere_datacenter = "SOF"

# vSphere cluster name where the infrastructure will be deployed #
vsphere_cluster = "Storage_IBM"

#===============================================================================
# Virtual machine parameters
#===============================================================================

# The name of the virtual machine #
vm_name = "orcl01"

# The datastore name used to store the files of the virtual machine #
vm_datastore = "Storage_Purestorage"

# The vSphere network name used by the virtual machine #
vm_network = "PG_Atlas_Teste"

# The netmask used to configure the network card of the virtual machine (example: 24) #
vm_netmask = "24"

# The network gateway used by the virtual machine #
vm_gateway = "192.168.30.1"

# The DNS server used by the virtual machine #
vm_dns = ["172.27.3.5", "172.27.3.6"]

# The domain name used by the virtual machine #
vm_domain = "sof.intra"

# The vSphere template the virtual machine is based on #
vm_template = "CentOS 7.8 - Docker Template"

# Use linked clone (true/false)
vm_linked_clone = "false"

# The number of vCPU allocated to the virtual machine #
vm_cpu = "1"

# The amount of RAM allocated to the virtual machine #
vm_ram = "1024"

# The IP address of the virtual machine #
vm_ip = "192.168.30.155"
